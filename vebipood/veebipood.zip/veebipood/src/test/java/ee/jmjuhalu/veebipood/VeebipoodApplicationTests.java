package ee.jmjuhalu.veebipood;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VeebipoodApplicationTests {

	@Test
	void contextLoads() {
	}

}
